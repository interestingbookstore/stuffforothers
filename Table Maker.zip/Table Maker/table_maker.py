from PIL import Image, ImageDraw, ImageFont
from PyBookFonts import *


def make_table(top_header, left_header, data, cell_width, cell_height, line_thickness, font, fontsize, save_name, background=(0, 0, 0, 0), line_color=(0, 0, 0), text_color=(0, 0, 0)):
    # Make sure that everything is nice
    lengths = [len(i) for i in data]
    if not lengths.count(lengths[0]) == len(data):
        raise IndexError('All rows are not the same length')

    # Turn everything into a list
    data = list(data)
    for index, i in enumerate(data):
        data[index] = list(data[index])

    # Add the left header
    if left_header is not None:
        for index, i in enumerate(left_header):
            data[index].insert(0, i)
    # Add top header
    blank_cell = False
    if top_header is not None:
        if len(top_header) == len(data[0]) - 1:
            blank_cell = True
            data.insert(0, tuple(['']) + top_header)
        else:
            data.insert(0, top_header)

    # Setup stuff
    rows, cols = len(data), len(data[0])
    xres, yres = cell_width * cols + line_thickness * (cols + 1), cell_height * rows + line_thickness * (rows + 1)
    full_width, full_height = cell_width + line_thickness, cell_height + line_thickness
    img = Image.new('RGBA', (xres, yres), background)
    font = ImageFont.truetype(font_shorts[font], fontsize)
    d = ImageDraw.Draw(img)

    # Draw vertical lines
    for i in range(cols + 1):
        if i == 0 and blank_cell:
            top = full_height + line_thickness // 2 - 1
        else:
            top = 0
        d.line((i * full_width + line_thickness // 2 - 1, top, i * full_width + line_thickness // 2 - 1, yres), line_color, line_thickness)

    # Draw horizontal lines
    for i in range(rows + 1):
        if i == 0 and blank_cell:
            left = full_width + line_thickness // 2 - 1
        else:
            left = 0
        d.line((left, i * full_height + line_thickness // 2 - 1, xres, i * full_height + line_thickness // 2 - 1), line_color, line_thickness)

    # Add text
    for index2, i in enumerate(data):
        for index, j in enumerate(i):
            d.text((index * full_width + line_thickness + cell_width // 2, index2 * full_height + line_thickness + cell_height // 2), str(j), text_color, font, 'mm')

    # Save
    img.save(save_name)


t = 'a', 'b', 'c'
l = 'hi', 'hello'
data = (0, 1, 2), (3, 4, 5)

make_table(t, l, data, 600, 300, 30, 'LatoL', 100, 'aaa2.png')
