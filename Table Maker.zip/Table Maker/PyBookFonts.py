from pathlib import Path

font_folder = './Fonts'

font_shorts = {}
for i in [(i, i.stem) for i in Path(font_folder).glob('**/*') if i.is_file()]:
    path = str(i[0]).replace('//', '/').replace('\\', '/')
    if path[-4:] != '.ttf':
        continue
    name = i[1].split('-')
    f_type = name[1]
    if 'Italic' in f_type:
        continue

    if 'Thin' in f_type:
        suffix = 'T'
    elif 'ExtraLight' in f_type:
        suffix = 'El'
    elif 'Light' in f_type:
        suffix = 'L'
    elif 'Regular' in f_type:
        suffix = ''
    elif 'Medium' in f_type:
        suffix = 'M'
    elif 'SemiBold' in f_type:
        suffix = 'Sb'
    elif 'ExtraBold' in f_type:
        suffix = 'Eb'
    elif 'Bold' in f_type:
        suffix = 'B'
    elif 'Black' in f_type:
        suffix = 'Bl'
    else:
        suffix = f_type
    font_shorts[name[0] + suffix] = path
